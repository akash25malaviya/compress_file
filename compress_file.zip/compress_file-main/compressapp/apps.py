from django.apps import AppConfig


class CompressappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'compressapp'
